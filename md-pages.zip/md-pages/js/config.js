config = {
    blog_name: "天狼星 ● 文档",
    per_page: 10,             // 首页每次载入文章列表数量
    file_server: "http://"+window.location.hostname+":80",
};
